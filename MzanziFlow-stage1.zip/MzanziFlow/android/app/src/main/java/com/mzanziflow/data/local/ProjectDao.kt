package com.mzanziflow.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(project: Project)

    @Update
    suspend fun update(project: Project)

    @Query("DELETE FROM projects WHERE projectId = :projectId")
    suspend fun deleteById(projectId: String)

    @Query("SELECT * FROM projects WHERE projectId = :projectId LIMIT 1")
    suspend fun getById(projectId: String): Project?

    /** Projects tab — every project the user owns or is a member of. Membership
     * filtering by userId happens in the Repository layer since `members` is a
     * JSON column here, not a queryable relational field. */
    @Query("SELECT * FROM projects ORDER BY lastModified DESC")
    fun observeAllProjects(): Flow<List<Project>>

    @Query("SELECT * FROM projects WHERE syncStatus = :status")
    suspend fun getProjectsBySyncStatus(status: SyncStatus = SyncStatus.PENDING): List<Project>

    @Query(
        """
        UPDATE projects SET syncStatus = :status, serverId = :serverId, lastModified = :lastModified
        WHERE projectId = :projectId
        """
    )
    suspend fun markSynced(projectId: String, serverId: String, status: SyncStatus, lastModified: Long)
}
