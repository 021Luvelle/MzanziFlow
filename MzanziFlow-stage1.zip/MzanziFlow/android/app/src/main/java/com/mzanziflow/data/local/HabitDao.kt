package com.mzanziflow.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface HabitDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(habit: Habit)

    @Update
    suspend fun update(habit: Habit)

    @Query("DELETE FROM habits WHERE habitId = :habitId")
    suspend fun deleteById(habitId: String)

    @Query("SELECT * FROM habits WHERE habitId = :habitId LIMIT 1")
    suspend fun getById(habitId: String): Habit?

    /** Habits tab — all habits for the current user, highest streak first. */
    @Query("SELECT * FROM habits WHERE userId = :userId ORDER BY streakCount DESC")
    fun observeHabitsForUser(userId: String): Flow<List<Habit>>

    /** Habit Streak Card, Screen 3 — used to show the top streak on the dashboard. */
    @Query("SELECT * FROM habits WHERE userId = :userId ORDER BY streakCount DESC LIMIT 1")
    fun observeTopStreak(userId: String): Flow<Habit?>

    @Query("SELECT * FROM habits WHERE syncStatus = :status")
    suspend fun getHabitsBySyncStatus(status: SyncStatus = SyncStatus.PENDING): List<Habit>

    @Query(
        """
        UPDATE habits SET syncStatus = :status, serverId = :serverId, lastModified = :lastModified
        WHERE habitId = :habitId
        """
    )
    suspend fun markSynced(habitId: String, serverId: String, status: SyncStatus, lastModified: Long)
}
