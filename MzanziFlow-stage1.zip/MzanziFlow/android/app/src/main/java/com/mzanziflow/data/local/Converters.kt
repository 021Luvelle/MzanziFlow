package com.mzanziflow.data.local

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

/**
 * Room cannot persist enums or complex objects directly, so we convert them
 * to/from primitive types Room understands (String / Long).
 */
class Converters {

    private val gson = Gson()

    // --- SyncStatus <-> String ---
    @TypeConverter
    fun fromSyncStatus(value: SyncStatus): String = value.name

    @TypeConverter
    fun toSyncStatus(value: String): SyncStatus = SyncStatus.valueOf(value)

    // --- List<ProjectMember> <-> JSON String ---
    @TypeConverter
    fun fromMemberList(value: List<ProjectMember>): String = gson.toJson(value)

    @TypeConverter
    fun toMemberList(value: String): List<ProjectMember> {
        val type = object : TypeToken<List<ProjectMember>>() {}.type
        return gson.fromJson(value, type) ?: emptyList()
    }
}
