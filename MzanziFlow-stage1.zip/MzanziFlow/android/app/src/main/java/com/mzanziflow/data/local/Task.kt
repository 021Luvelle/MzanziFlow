package com.mzanziflow.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.UUID

/**
 * Local (Room) representation of a task. Mirrors the MongoDB `tasks` collection
 * (server/src/models/Task.js) and the JSON payload in Part 1, Section 5 (API Design).
 *
 * syncStatus / lastModified drive the offline-first sync flow described in
 * R5 and the Sequence Diagram (Section 6.3).
 */
@Entity(
    tableName = "tasks",
    foreignKeys = [
        ForeignKey(
            entity = User::class,
            parentColumns = ["userId"],
            childColumns = ["userId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("userId"), Index("dueDate"), Index("syncStatus"), Index("projectId")]
)
data class Task(
    @PrimaryKey val taskId: String = UUID.randomUUID().toString(), // local temp ID; replaced with server ID on first sync
    val userId: String,
    val title: String,                 // Required, max 100 chars
    val description: String? = null,   // Optional, max 500 chars
    val dueDate: Long? = null,         // Epoch millis; ISO 8601 on the wire, must be a future date on creation
    val priority: Int = 2,             // 1=Low, 2=Medium, 3=High
    val category: String = "Academic", // Academic, Personal, Extracurricular, Health, or custom (max 30 chars)
    val projectId: String? = null,     // FK -> Project, null for personal tasks
    val assignedTo: String? = null,    // userId of assignee within a shared project
    val isCompleted: Boolean = false,
    val reminderOffsetMinutes: Int? = null, // 15, 60, or 1440 (1 day) — null = no reminder
    val syncStatus: SyncStatus = SyncStatus.PENDING,
    val lastModified: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis(),
    val serverId: String? = null       // MongoDB _id once synced; null while PENDING and locally-only
)
