package com.mzanziflow.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(task: Task)

    @Update
    suspend fun update(task: Task)

    @Query("DELETE FROM tasks WHERE taskId = :taskId")
    suspend fun deleteById(taskId: String)

    @Query("SELECT * FROM tasks WHERE taskId = :taskId LIMIT 1")
    suspend fun getById(taskId: String): Task?

    /** Home Dashboard: all of a user's tasks, most urgent first. */
    @Query("SELECT * FROM tasks WHERE userId = :userId ORDER BY isCompleted ASC, dueDate ASC")
    fun observeTasksForUser(userId: String): Flow<List<Task>>

    /** Home Dashboard: today's tasks (Task Summary Card, Screen 3). */
    @Query(
        """
        SELECT * FROM tasks
        WHERE userId = :userId AND dueDate BETWEEN :startOfDay AND :endOfDay
        ORDER BY dueDate ASC
        """
    )
    fun observeTasksDueOn(userId: String, startOfDay: Long, endOfDay: Long): Flow<List<Task>>

    /** Upcoming Deadlines Section, Screen 3 — next N tasks, soonest first. */
    @Query(
        """
        SELECT * FROM tasks
        WHERE userId = :userId AND isCompleted = 0 AND dueDate IS NOT NULL
        ORDER BY dueDate ASC LIMIT :limit
        """
    )
    fun observeUpcomingDeadlines(userId: String, limit: Int = 3): Flow<List<Task>>

    /** Shared Project screen, Screen 5 — tasks filtered by projectId. */
    @Query("SELECT * FROM tasks WHERE projectId = :projectId ORDER BY dueDate ASC")
    fun observeTasksForProject(projectId: String): Flow<List<Task>>

    /** Used by SyncWorker to batch all unsynced changes (R5, Sequence Diagram step 3). */
    @Query("SELECT * FROM tasks WHERE syncStatus = :status")
    suspend fun getTasksBySyncStatus(status: SyncStatus = SyncStatus.PENDING): List<Task>

    @Query("UPDATE tasks SET syncStatus = :status WHERE taskId = :taskId")
    suspend fun updateSyncStatus(taskId: String, status: SyncStatus)

    @Query(
        """
        UPDATE tasks SET syncStatus = :status, serverId = :serverId, lastModified = :lastModified
        WHERE taskId = :taskId
        """
    )
    suspend fun markSynced(taskId: String, serverId: String, status: SyncStatus, lastModified: Long)

    @Query("SELECT COUNT(*) FROM tasks WHERE syncStatus = 'PENDING'")
    fun observePendingCount(): Flow<Int>
}
