package com.mzanziflow.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import java.util.UUID

/**
 * Local (Room) representation of a shared project. Mirrors the MongoDB
 * `projects` collection. Member roles (Owner/Editor/Viewer) are stored as a
 * List<ProjectMember>, persisted via Converters (Gson JSON column).
 */
@Entity(tableName = "projects")
@TypeConverters(Converters::class)
data class Project(
    @PrimaryKey val projectId: String = UUID.randomUUID().toString(),
    val ownerId: String,
    val name: String,                     // Required, max 60 chars
    val description: String? = null,
    val members: List<ProjectMember> = emptyList(),
    val syncStatus: SyncStatus = SyncStatus.PENDING,
    val lastModified: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis(),
    val serverId: String? = null
)

/**
 * A single collaborator entry within a Project.members list.
 * role: "OWNER" | "EDITOR" | "VIEWER" (Section 6.2, Class Diagram).
 */
data class ProjectMember(
    val userId: String,
    val displayName: String,
    val role: String
)
