package com.mzanziflow.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

/**
 * Single Room database for MzanziFlow. Acts as the local source of truth for
 * the offline-first architecture (R5).
 *
 * Version history:
 *   1 - Initial schema (Stage 1): users, tasks, projects, habits.
 */
@Database(
    entities = [User::class, Task::class, Project::class, Habit::class],
    version = 1,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class MzanziFlowDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun taskDao(): TaskDao
    abstract fun projectDao(): ProjectDao
    abstract fun habitDao(): HabitDao

    companion object {
        private const val DATABASE_NAME = "mzanziflow.db"

        @Volatile
        private var INSTANCE: MzanziFlowDatabase? = null

        fun getInstance(context: Context): MzanziFlowDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    MzanziFlowDatabase::class.java,
                    DATABASE_NAME
                )
                    // No destructive migrations in production; Stage 1 only —
                    // real migrations will be added once the schema stabilises.
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
