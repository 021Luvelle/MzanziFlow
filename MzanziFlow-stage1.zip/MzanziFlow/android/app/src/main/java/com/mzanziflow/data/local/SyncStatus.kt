package com.mzanziflow.data.local

/**
 * Tracks the synchronisation state of a locally-stored record against the
 * MzanziFlow REST API / MongoDB Atlas.
 *
 * PENDING   - created/edited/deleted locally, not yet confirmed by the server.
 * SYNCED    - matches the server copy as of lastModified.
 * CONFLICT  - server has a newer version than the local edit; requires
 *             resolution (see R5 / Sequence Diagram 6.3, step 8).
 */
enum class SyncStatus {
    PENDING,
    SYNCED,
    CONFLICT
}
