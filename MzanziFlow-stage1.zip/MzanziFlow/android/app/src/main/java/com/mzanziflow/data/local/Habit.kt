package com.mzanziflow.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.UUID

/**
 * Local (Room) representation of a habit. Mirrors the MongoDB `habits` collection.
 * Streak calculation logic lives in HabitRepository (Stage 3+), not in the entity.
 */
@Entity(
    tableName = "habits",
    foreignKeys = [
        ForeignKey(
            entity = User::class,
            parentColumns = ["userId"],
            childColumns = ["userId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("userId"), Index("syncStatus")]
)
data class Habit(
    @PrimaryKey val habitId: String = UUID.randomUUID().toString(),
    val userId: String,
    val title: String,                 // Required, max 50 chars
    val frequency: String = "daily",   // Enum: "daily", "weekly", "custom"
    val streakCount: Int = 0,          // Auto-incremented, min 0
    val lastCompletedDate: Long? = null, // ISO date only (epoch millis at midnight, local)
    val syncStatus: SyncStatus = SyncStatus.PENDING,
    val lastModified: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis(),
    val serverId: String? = null
)
