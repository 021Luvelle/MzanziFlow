# MzanziFlow — Requirements Traceability Matrix

This matrix maps every Part 1 requirement to its Part 2 implementation, test,
evidence screenshot, and POE section. It is built incrementally as each
development stage lands — entries marked *Pending* have not been implemented
yet and must not be reported as complete in the POE until they genuinely are.

| Req | Requirement | Implementation | Source file(s) | Test | Evidence | POE Section | Status |
|---|---|---|---|---|---|---|---|
| R1 (partial) | User data model, password kept server-side only | User Room entity, User Mongoose model | `android/.../data/local/User.kt`, `server/src/models/User.js` | Schema validation (smoke test) | — | 6. Database | Done |
| R4 (partial) | REST API skeleton, health endpoint, rate limiting, security middleware | Express app factory | `server/src/app.js`, `server/src/server.js` | `GET /api/health` returns 200 (verified) | Screenshot 15 — REST API (once endpoints are live) | 7. REST API | Done |
| R5 (partial) | Room entities + DAOs with syncStatus/lastModified fields | Task/Project/Habit/User entities & DAOs | `android/.../data/local/*.kt` | Pending — Room instrumentation test (Stage 2+) | — | 8. Offline Functionality | Done |
| Data Dictionary | Field-level types & validation for User/Task/Project/Habit | Room entities + Mongoose schemas | `android/.../data/local/*.kt`, `server/src/models/*.js` | Schema validation (smoke test — valid/invalid cases passed) | — | 6. Database | Done |
| R1 (auth flow) | Registration, login, JWT issuance, Firebase Auth | Pending | — | — | Screenshots 1–2 | 5. Authentication | Pending |
| R2 | Google Sign-In SSO | Pending | — | — | — | 5. Authentication | Pending |
| R3 | Settings screen | Pending | — | — | Screenshot 12 | 9. User Interface | Pending |
| R4 (endpoints) | Task/Project/Habit/Sync CRUD endpoints | Pending | — | — | Screenshot 15 | 7. REST API | Pending |
| R5 (sync flow) | WorkManager SyncWorker, conflict resolution | Pending | — | — | Screenshots 7–8 | 8. Offline Functionality | Pending |
| R6 | FCM + local notification fallback | Pending | — | — | — | 9. User Interface | Pending |
| R7 | Multi-language support | Pending | — | — | Screenshot 13 | 9. User Interface | Pending |
| R8 | Habit streaks, shared projects, data export | Pending | — | — | Screenshots 9–10 | 9. User Interface | Pending |
| — | GitHub Actions CI/CD | Pending | — | — | Screenshots 17–18 | 12. CI/CD | Pending |

**Note on "Done" rows above:** these were implemented and smoke-tested in this
sandbox (Express app boots, `/api/health` returns 200, Mongoose schemas
correctly accept valid and reject invalid data). Room/Android code could not
be compiled in this environment (no network access to Google's Maven
repository for the Android Gradle Plugin/SDK), so it has been checked for
syntax/brace correctness only — build it in Android Studio and run a Room
instrumentation test before citing it as verified working in the POE.
