const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

/**
 * Builds and returns the Express app WITHOUT starting it or connecting to
 * MongoDB. Kept separate from server.js so tests (supertest) can exercise
 * the app against an in-memory MongoDB instance without binding a port.
 */
function createApp() {
  const app = express();

  app.use(helmet());
  app.use(cors());
  app.use(express.json({ limit: '1mb' })); // profile images are base64, hence the higher limit

  // R4: 100 requests per 15 minutes per user (falls back to per-IP when unauthenticated)
  const limiter = rateLimit({
    windowMs: Number(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000,
    max: Number(process.env.RATE_LIMIT_MAX) || 100,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'Too many requests, please try again later.' }
  });
  app.use('/api', limiter);

  // GET /api/health - liveness check, no auth required (Section 16)
  app.get('/api/health', (req, res) => {
    res.status(200).json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // Feature routers are mounted here incrementally as each stage lands:
  // app.use('/api/auth', require('./routes/authRoutes'));
  // app.use('/api/tasks', require('./routes/taskRoutes'));
  // app.use('/api/projects', require('./routes/projectRoutes'));
  // app.use('/api/habits', require('./routes/habitRoutes'));
  // app.use('/api/sync', require('./routes/syncRoutes'));

  // 404 handler
  app.use((req, res) => {
    res.status(404).json({ error: 'Not found' });
  });

  // Centralised error handler - never leaks stack traces to the client (Section 22)
  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    console.error(err);
    const status = err.status || 500;
    res.status(status).json({ error: err.publicMessage || 'Internal server error' });
  });

  return app;
}

module.exports = { createApp };
