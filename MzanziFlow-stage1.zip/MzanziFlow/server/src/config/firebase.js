const admin = require('firebase-admin');

/**
 * Initialises the Firebase Admin SDK so the API can:
 *  - verify Firebase ID tokens sent by the Android client (R1, R2)
 *  - send Firebase Cloud Messaging pushes (R6)
 *
 * Requires FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, FIREBASE_PRIVATE_KEY
 * in the environment (see .env.example). Throws clearly if they are missing
 * rather than silently running with a broken auth layer.
 */
function initFirebaseAdmin() {
  if (admin.apps.length > 0) {
    return admin.app();
  }

  const { FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, FIREBASE_PRIVATE_KEY } = process.env;

  if (!FIREBASE_PROJECT_ID || !FIREBASE_CLIENT_EMAIL || !FIREBASE_PRIVATE_KEY) {
    throw new Error(
      'Firebase Admin credentials are missing. Set FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL ' +
        'and FIREBASE_PRIVATE_KEY in your .env (see .env.example) using your Firebase service account.'
    );
  }

  return admin.initializeApp({
    credential: admin.credential.cert({
      projectId: FIREBASE_PROJECT_ID,
      clientEmail: FIREBASE_CLIENT_EMAIL,
      // .env stores literal \n; convert to real newlines for the PEM key.
      privateKey: FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n')
    })
  });
}

module.exports = { admin, initFirebaseAdmin };
