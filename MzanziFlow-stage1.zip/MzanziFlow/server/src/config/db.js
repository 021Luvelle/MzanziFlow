const mongoose = require('mongoose');

/**
 * Connects to MongoDB Atlas using the URI from environment variables.
 * Called once from app.js at startup (and separately by tests, which point
 * MONGODB_URI at an in-memory instance - see server/tests/setup.js).
 */
async function connectDB(uri = process.env.MONGODB_URI) {
  if (!uri) {
    throw new Error(
      'MONGODB_URI is not set. Copy .env.example to .env and provide your MongoDB Atlas connection string.'
    );
  }

  mongoose.set('strictQuery', true);

  await mongoose.connect(uri);

  console.log(`MongoDB connected: ${mongoose.connection.host}`);
  return mongoose.connection;
}

async function disconnectDB() {
  await mongoose.disconnect();
}

module.exports = { connectDB, disconnectDB };
