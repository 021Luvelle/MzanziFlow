const mongoose = require('mongoose');

const memberSchema = new mongoose.Schema(
  {
    userId: { type: String, required: true },
    displayName: { type: String, required: true },
    role: { type: String, enum: ['OWNER', 'EDITOR', 'VIEWER'], required: true }
  },
  { _id: false }
);

/**
 * projects collection. members embeds role-based collaborators
 * (Section 6.2 Class Diagram; Screen 5 - Members tab).
 */
const projectSchema = new mongoose.Schema(
  {
    ownerId: { type: String, required: true, index: true },
    name: { type: String, required: true, maxlength: 60 },
    description: { type: String, default: null, maxlength: 300 },
    members: { type: [memberSchema], default: [] },
    localProjectId: { type: String, default: null },
    lastModified: { type: Date, default: Date.now }
  },
  { timestamps: true }
);

module.exports = mongoose.model('Project', projectSchema);
