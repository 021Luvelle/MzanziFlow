const mongoose = require('mongoose');

/**
 * users collection.
 * userId is the Firebase Auth UID (not a Mongo ObjectId) so the client and
 * server always agree on the same identifier - see Part 1, Data Dictionary.
 *
 * passwordHash exists only for completeness/documentation: in practice,
 * Firebase Authentication owns password storage and verification, so the
 * API never receives or stores a raw password. This field is left unused
 * unless a future non-Firebase auth path is added.
 */
const userSchema = new mongoose.Schema(
  {
    userId: { type: String, required: true, unique: true, index: true },
    email: {
      type: String,
      required: true,
      unique: true,
      match: /^[\w.-]+@[\w.-]+\.\w{2,}$/
    },
    displayName: { type: String, required: true, maxlength: 50 },
    profileImageBase64: { type: String, default: null }, // max 500KB enforced in controller
    bio: { type: String, default: null, maxlength: 300 },
    preferredLanguage: { type: String, enum: ['en', 'zu', 'af'], default: 'en' },
    fcmToken: { type: String, default: null },
    notificationPrefs: {
      taskReminders: { type: Boolean, default: true },
      habitReminders: { type: Boolean, default: true },
      collaboration: { type: Boolean, default: true },
      loadShedding: { type: Boolean, default: true }
    }
  },
  { timestamps: true } // adds createdAt / updatedAt
);

module.exports = mongoose.model('User', userSchema);
