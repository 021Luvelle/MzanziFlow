const mongoose = require('mongoose');

/**
 * habits collection. Streak calculation itself happens client-side
 * (HabitRepository, Stage 3) and server-side (habit controller, Stage 3) -
 * this schema just stores the result plus enough history to recompute it.
 */
const habitSchema = new mongoose.Schema(
  {
    userId: { type: String, required: true, index: true },
    title: { type: String, required: true, maxlength: 50 },
    frequency: { type: String, enum: ['daily', 'weekly', 'custom'], default: 'daily' },
    streakCount: { type: Number, default: 0, min: 0 },
    lastCompletedDate: { type: Date, default: null },
    syncStatus: { type: String, enum: ['PENDING', 'SYNCED', 'CONFLICT'], default: 'SYNCED' },
    localHabitId: { type: String, default: null },
    lastModified: { type: Date, default: Date.now }
  },
  { timestamps: true }
);

module.exports = mongoose.model('Habit', habitSchema);
