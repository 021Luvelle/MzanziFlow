const mongoose = require('mongoose');

/**
 * tasks collection. Field names/types match Part 1, Section 5 (API Design
 * JSON payload) and Section 7 (Data Dictionary) exactly so client <-> server
 * mapping stays 1:1.
 */
const taskSchema = new mongoose.Schema(
  {
    userId: { type: String, required: true, index: true },
    title: { type: String, required: true, maxlength: 100 },
    description: { type: String, default: null, maxlength: 500 },
    dueDate: { type: Date, default: null, index: true },
    priority: { type: Number, enum: [1, 2, 3], default: 2 }, // 1=Low, 2=Medium, 3=High
    category: { type: String, default: 'Academic', maxlength: 30 },
    projectId: { type: mongoose.Schema.Types.ObjectId, ref: 'Project', default: null },
    assignedTo: { type: String, default: null }, // userId of assignee
    isCompleted: { type: Boolean, default: false },
    reminderOffsetMinutes: { type: Number, default: null }, // 15, 60, 1440
    syncStatus: { type: String, enum: ['PENDING', 'SYNCED', 'CONFLICT'], default: 'SYNCED' },
    localTaskId: { type: String, default: null }, // the client's temp UUID, for sync reconciliation
    lastModified: { type: Date, default: Date.now, index: true }
  },
  { timestamps: true }
);

module.exports = mongoose.model('Task', taskSchema);
